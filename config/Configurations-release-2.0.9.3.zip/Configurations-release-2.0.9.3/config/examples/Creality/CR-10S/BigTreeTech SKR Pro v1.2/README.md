## CR-10S with SKR Pro V1.2

With support for:
 - TMC2209 Stepper Drivers
 - BLTouch Probe
 - Advanced Pause (`M600`) and Nozzle Park (`G27`) with Filament Change
